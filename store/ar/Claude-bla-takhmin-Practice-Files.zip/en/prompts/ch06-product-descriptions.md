# Chapter 6: product descriptions with three examples

> Names are fictional, for teaching.

## The weak prompt

```
Write a catchy description for each of these coffees:
Kenya Nyeri, Brazil Cerrado, Ramadan Blend.
```

## The improved prompt

```
Write product descriptions for Nada Roastery. The reader is a customer browsing on a phone and deciding in seconds.
Follow the examples' structure and voice, not their wording: one line on flavor and feel, one line on roast and brewing, about 20 words in total.
<examples>
<example>
Ethiopia Yirgacheffe: bright, lemony acidity and a delicate floral finish that lingers.
Light roast, at its best as a pour-over.
</example>
<example>
Colombia Huila: a calm balance of sweetness and acidity, with caramel and red apple.
Medium roast that works for espresso and filter alike.
</example>
<example>
Winter Blend: a full body for cold days, dark chocolate with a hint of spice.
Medium-dark roast that stands up to milk.
</example>
</examples>
Write one description for each coffee below, using only the notes given for it.
If the notes are empty, make the first line "Tasting notes coming soon." Don't suggest flavors.
<products>
1. Kenya Nyeri | blackcurrant, high acidity | light roast | pour-over
2. Brazil Cerrado | hazelnut, milk chocolate, low acidity | medium | espresso
3. Ramadan Blend | dates and cardamom, full body | medium-dark | Arabic or French press
4. Honduras | — | medium | filter
</products>
```

## Consistency checklist

- [ ] Every description is 25 words or fewer
- [ ] No flavor that isn't in the input
- [ ] No phrase copied word for word from the examples
- [ ] Product 4's first line is "Tasting notes coming soon."

_Last reviewed: 2026-10-17_
