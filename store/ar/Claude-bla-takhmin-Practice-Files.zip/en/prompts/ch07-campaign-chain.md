# Chapter 7: the marketing-plan chain (three stages)

> Names and figures are fictional, for teaching. The files sales-aug-oct.csv and november-events.txt are not included; use your own.

## Stage 1 · Analysis

```
I'm Rana, owner of Nada Roastery in Amman. I'm planning a marketing campaign for November 2026.
I've attached two files: sales-aug-oct.csv and november-events.txt.

The task right now is analysis only, not the plan:
- Identify five sales opportunities for November and rank them from strongest to weakest.
- For each: one sentence describing it, the figure or observation from the files that supports it, and your confidence (high, medium, low) with the reason.
- If the data doesn't give enough evidence for an opportunity, leave it out.

Stop after the list. I'll choose two before we move on to the plan.
```
**Pass condition:** every opportunity is backed by a figure from the file.

## Stage 2 · Plan

```
I've chosen opportunities 1 and 3. The ad budget is 300 JOD for the whole month.
Write a one-page plan covering: a measurable goal, the audience, the core message, the channels, and the budget split across channels.
Make sure the split totals no more than 300 JOD, and that each channel has one metric we'll judge it by.
Don't write any post copy yet.
```
**Pass condition:** the total stays within budget, and each channel has a measurable goal.

## Stage 3 · Execution

```
The plan is approved with my changes: Instagram 180 JOD, WhatsApp to existing customers 70, in-store samples 50.
Write a four-week content calendar: date, channel, the opportunity each post serves, and the post copy.
Write the copy in the voice of the three examples in <examples>; follow their structure, not their wording.
<examples>
[3 past posts that performed well]
</examples>
Show the calendar, then create it as a downloadable Excel file.
```

## Criteria-based review

```
Check every post in the calendar against four criteria:
1. Tied to one of the two opportunities.
2. Under 60 words.
3. One clear call to action.
4. No price that isn't in the plan.
Show a table of posts that fail one or more criteria, with the criterion and why.
Don't change anything until I've seen the table.
```

_Last reviewed: 2026-10-17_
