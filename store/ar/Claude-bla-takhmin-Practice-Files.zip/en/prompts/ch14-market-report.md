# Market research report: the full chain (Chapter 14)

_Claude Without Guesswork · October 2026 Edition · companion pack. Copy, then replace every [bracketed slot]._

## Stage 0 · decision brief

```text
Help me write a one-page decision brief. Don't research anything yet.
Decision: should Nada Roastery launch an office coffee subscription in Amman in Q1 2027?
Options: (a) launch to all offices, (b) run a small pilot, (c) don't launch.
My constraints: up to 3,000 JOD to invest; one delivery day a week; I can lend grinders but not espresso machines.
Ask me questions until you can fill these sections: what we must believe for each option to be right, the numbers that would make me say yes or no, and what I already know vs. what I'm guessing.
```

## Stage 1 · questions

```text
From the brief above, write five research questions that public sources could plausibly answer, each with the six edges from Chapter 13 (topic, place, time, source rules, exclusions, output).
For each, say which "we must believe" line it tests.
Then list the questions that public research can't answer and that I'll need my own data for.
```

## Stage 2 · research

```text
Use the research tool on the five questions below. Work through them in order.
Source rules: Jordan first; label any Gulf or global figure as a comparison. Prefer company pages, official statistics, and trade bodies. Mark vendor blogs and press releases as weak.
For every finding: claim, source, date of the data, source type, confidence with reason.
End with: what you couldn't find, and which "we must believe" lines remain untested.
<questions>[the five questions]</questions>
```

## Interview guide

```text
I'll call office managers at 12 businesses within our delivery zone. Write a 10-minute interview guide to learn how they handle staff coffee today, what they spend, and what frustrates them.
Rules: no leading questions, no mention of our product until the last two minutes, ask about past behavior rather than future intentions ("what did you buy last month," not "would you buy").
Then review your own guide and flag any question that could still bias the answer.
```

## Summarizing the calls

```text
Below are my notes from 12 calls, each in its own <call> tag with an ID.
Summarize: how many currently buy coffee and what kind; monthly spend where stated; top frustrations with how many calls mentioned each; and every direct quote about price.
Count, don't estimate. If a call didn't cover a question, it doesn't count toward that answer.
Show the call IDs behind each count.
```

## Report

```text
Write a decision report (max two pages) using only the audited findings in <evidence> and the call summary in <calls>.
Structure:
1. Recommendation in two sentences.
2. What the evidence shows (each point cites a finding ID or call IDs).
3. Assumptions we're still making, each with how a pilot would test it.
4. Risks, with the cheapest way to limit each.
5. What would change this recommendation.
Keep comparison-only figures labeled. Don't introduce any number that isn't in the evidence.
```

## Red-team review

```text
You're a skeptical investor reviewing this decision report. Using only the report and the evidence table below:
1. Find every claim not supported by the cited evidence.
2. Find the weakest assumption, and explain how it could make the recommendation wrong.
3. Suggest one cheaper or faster test than the proposed pilot, if one exists.
Be direct. Don't rewrite the report.
```

