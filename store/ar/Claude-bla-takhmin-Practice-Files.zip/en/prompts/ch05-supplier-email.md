# Chapter 5: copy-ready test prompts

> Names and figures are fictional, for teaching.

## The weak prompt

```
Write an email to the supplier about the late shipment.
```

## The improved prompt (ARROWS)

```
I'm Rana, owner of Nada Roastery in Amman; we sell specialty coffee online. I need an email to our supplier in Colombia, Finca Verde. We've worked with them for 3 years and the relationship is good.

Facts:
- Order PO-2291: 120 kg of green Huila, due 1 September.
- 3 weeks on, it hasn't shipped, and they haven't answered our last two emails.
- Our stock of this coffee covers only 10 more days.

Aim: get a confirmed ship date within 48 hours while keeping the relationship.

Write it in English, 100 to 150 words, with a clear subject line.
Tone: firm and friendly. Don't apologize on our behalf, don't threaten, don't over-flatter.
End with two specific requests they can answer: a confirmed ship date, and the tracking number as soon as it exists.
```

## Scoring checklist (one point per condition)

- [ ] Mentions order PO-2291
- [ ] Asks for something specific (ship date + tracking number)
- [ ] No blanks such as [Supplier Name]
- [ ] No apology on the shop's behalf
- [ ] Between 100 and 150 words

## Second prompt pair (5.4): explain the "why"

```
Write a short ad for the new Winter Blend. Don't use abbreviations.
```

```
Write a short ad for the new Winter Blend (250 g, 9 JOD).
The text will be read aloud by a synthetic voice in a voice message, so write numbers and units out in full words, and avoid anything that doesn't read aloud clearly.
```

## Language pack (5.7)

```
Write in plain international English with US spelling, unless I ask otherwise.
My customers are in Jordan: prices in JOD with two decimals, metric units.
Write dates as 1 Sep 2026, never in all-number form.
Keep coffee origins (Huila, Yirgacheffe…) and order codes exactly as written.
When I ask for Arabic copy, use Modern Standard Arabic with Western digits 0–9.
```

## Let Claude ask first (5.8)

```
Before you start, ask me up to three questions, but only ones whose answers would change the result. If nothing is worth asking, just begin.
```

_Last reviewed: 2026-10-17_
