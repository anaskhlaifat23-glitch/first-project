# Documents, photos, and charts (Chapter 15)

_Claude Without Guesswork · October 2026 Edition · companion pack. Copy, then replace every [bracketed slot]._

## Extraction prompt

```text
From the attached supplier-prices-oct.pdf, build one table of every coffee offered, with columns: supplier, coffee, grade, USD/kg, minimum order (kg), lead time (days), and the PDF viewer page it came from.
Copy values exactly; don't convert or round.
If a value is missing or shown as a dash, write "not stated."
Below the table, list every condition from the terms pages that changes the real price or availability (validity dates, fees, stock limits), with its page.
```

## Photo extraction

```text
Transcribe the items and quantities from this delivery note into a table.
If any character is unclear, write it as [?] and don't guess it.
Then check whether the listed quantities add up to the stated total. If one quantity is unclear, say what value the total implies, and label it "inferred from total."
```

## Version comparison

```text
Compare the two attached files: <old> is price-list-sep.pdf and <new> is price-list-oct.pdf.
List every difference as a table: item or clause, old wording or value, new wording or value, and page in each file.
Include changes in terms, dates, fees, and minimums, not just prices.
Then mark which differences cost us money or reduce our options, and why.
If the files are identical in a section, say so; don't summarize sections that didn't change.
```

## Chart reading

```text
Describe what this chart shows: axes, units, time period, and the main trend.
If you estimate any values from the chart, label each "read from chart, approximate" and round to the nearest gridline.
Tell me whether the chart's source and date are visible.
```

