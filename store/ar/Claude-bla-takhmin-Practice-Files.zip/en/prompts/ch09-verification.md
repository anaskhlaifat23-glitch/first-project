# Chapter 9: a legitimate way out, and verification

## The improved research prompt

```
Search the web for published data on [topic] in [country], or in [wider region] if there's no country-specific data.

For every figure you give:
- The source, the link to the page you opened, and the year of the data.
- Whether it's for [country] specifically, the region, or a global estimate.

If you can't find a documented figure for an item, write "No published data found" and don't estimate it.
At the end, separate clearly what you found in sources from what is your own inference.
```

## Lines worth keeping

```
If you're not sure or can't find it, write: Not available.
After each claim, name its source. Remove any claim you can't source.
Answer only from the attached documents, not from your general knowledge.
```

## Verification protocol (by claim type)

| Claim type | How to verify | Risk |
|---|---|---|
| Number or statistic | Open the source; confirm number, country, year | High |
| Direct quote | Find the exact words in the original | High |
| Reference or study | Confirm it exists and says what's attributed to it | High |
| Current, changing fact | Recent official source, or web search with the date | Medium |
| Calculation on your data | Recalculate a sample, or ask for the formula | Medium |
| Stable general fact | Usually no check needed | Low |
| Inference or opinion | Evaluate the evidence and alternatives | Depends |

_Last reviewed: 2026-10-17_
