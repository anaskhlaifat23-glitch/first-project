# Pricing tool: build and fix prompts (Chapter 20)

_Claude Without Guesswork · October 2026 Edition · companion pack. Copy, then replace every [bracketed slot]._

## Build prompt

```text
Build a small interactive pricing tool as an artifact.
Users: my shop staff, on a phone or laptop. They are not technical.
Inputs (with these defaults): green cost per kg 8.25 JOD; roast loss 16%; bag size 250 g; packaging per bag 0.40 JOD; labor & energy per kg 2.00 JOD; target retail margin 55%; wholesale discount 18%.
Calculations: exactly the five formulas below. Calculate at full precision; round only for display.
<formulas> 
| Step | Formula |
|---|---|
| Roasted cost per kg | green cost per kg ÷ (1 − roast loss) + labor & energy per kg |
| Unit cost (per bag) | roasted cost per kg × bag size in kg + packaging per bag |
| Retail price | unit cost ÷ (1 − target margin), rounded UP to the next 0.25 JOD |
| Wholesale price | retail price × (1 − wholesale discount), to 2 decimals |
| Wholesale margin | (wholesale price − unit cost) ÷ wholesale price |
 </formulas>
Rounding: retail rounds UP to the next 0.25 JOD, but a price already on a 0.25 step must stay unchanged.
Validation: if roast loss or margin is ≥ 100%, or any input is blank or negative, show a plain-language error and no prices.
Warning: if wholesale margin is below 35%, show a red warning under the wholesale price.
Also add a "Run tests" button that runs these six cases and shows pass or fail for each:
<tests> 
| # | Inputs that differ from T1 | Unit cost | Retail | Wholesale | W. margin | Expect |
|---|---|---|---|---|---|---|
| T1 | Green 8.25/kg, loss 16%, 250 g, pack 0.40, labor 2.00/kg, margin 55%, discount 18% | 3.36 | 7.50 | 6.15 | 45.4% | No warning |
| T2 | 1,000 g bag, pack 0.70, margin 50% | 12.52 | 25.25 | 20.71 | 39.5% | No warning |
| T3 | Discount 35% | 3.36 | 7.50 | 4.88 | 31.2% | Warning |
| T4 | Green 7.20/kg, loss 20% | 3.15 | 7.00 | 5.74 | 45.1% | Retail exactly 7.00 |
| T5 | Loss 100% | — | — | — | — | Clear error, no price |
| T6 | Margin field left blank | — | — | — | — | Clear error, no price |
 </tests>
Before building, ask me up to three questions if anything in this spec is ambiguous.
```

## Fix prompt

```text
T4 fails: expected 7.00, got 7.25. I think floating-point error pushes an exact quarter step over the boundary before rounding up.
Fix the rounding so values within a tiny tolerance of a 0.25 step aren't rounded up. Explain the fix in two sentences, then rerun all six tests and show the results.
```

## Formulas

| Step | Formula |
|---|---|
| Roasted cost per kg | green cost per kg ÷ (1 − roast loss) + labor & energy per kg |
| Unit cost (per bag) | roasted cost per kg × bag size in kg + packaging per bag |
| Retail price | unit cost ÷ (1 − target margin), rounded UP to the next 0.25 JOD |
| Wholesale price | retail price × (1 − wholesale discount), to 2 decimals |
| Wholesale margin | (wholesale price − unit cost) ÷ wholesale price |

## Test cases

Unit cost is shown rounded; the tool must calculate at full precision and round only for display.

| # | Inputs that differ from T1 | Unit cost | Retail | Wholesale | W. margin | Expect |
|---|---|---|---|---|---|---|
| T1 | Green 8.25/kg, loss 16%, 250 g, pack 0.40, labor 2.00/kg, margin 55%, discount 18% | 3.36 | 7.50 | 6.15 | 45.4% | No warning |
| T2 | 1,000 g bag, pack 0.70, margin 50% | 12.52 | 25.25 | 20.71 | 39.5% | No warning |
| T3 | Discount 35% | 3.36 | 7.50 | 4.88 | 31.2% | Warning |
| T4 | Green 7.20/kg, loss 20% | 3.15 | 7.00 | 5.74 | 45.1% | Retail exactly 7.00 |
| T5 | Loss 100% | — | — | — | — | Clear error, no price |
| T6 | Margin field left blank | — | — | — | — | Clear error, no price |
