# Chapter 8: long documents

## Documents with clear identities (documents first, question last)

```
<documents>
<document index="1">
<source>[Document name · date · status]</source>
<content>
[paste or attach]
</content>
</document>
<document index="2">
<source>[Document name · date · what it amends]</source>
<content>
[paste or attach]
</content>
</document>
</documents>
Where document 2 conflicts with document 1, document 2 is newer and binding.
Question: [your question, last]
```

## Quote first, then answer

```
First, extract from the documents every passage about [topic], word for word, putting each in a <quote> tag with the document number and clause.
If you find no relevant passage, write: "No relevant passage."
Then, in an <answer> tag, answer the question using only those quotes, citing the quote number after each sentence.
Don't use your general knowledge of [field].
```

## Coverage test

```
Before we start: list the main section or clause headings in the attached document, with the page each one starts on in the PDF viewer. Don't summarize anything yet.
```

## Let Claude flag conflicts

```
Before you start, if anything in these instructions conflicts with something else here or with my general instructions, point it out and ask me which takes priority. If there's no conflict, just begin.
```

_Last reviewed: 2026-10-17_
