# Companion Pack (practice files): *Claude Without Guesswork* (October 2026 Edition)

Editable templates, practice data, plain-text prompts, and code for the book. No public download link exists; this folder ships with the book.

Your purchase includes three files:
1. *Claude Without Guesswork* (PDF): the book.
2. *The 120-Prompt Playbook* (PDF): all 120 prompts from Chapter 32, designed and sorted by job.
3. This companion pack (ZIP): the practice files and templates you work with while reading. The book calls it the "companion pack".

## templates/
- `arrows-template.md`: the ARROWS prompt template (Ch. 5)
- `product-descriptions-v1.md`: reusable template with slots (Ch. 6)
- `handoff-summary.md`: carry context into a new chat (Ch. 7)
- `prompt-card.md`: document a reusable prompt (Ch. 9)
- `test-set-log.xlsx`: test-set log with pass-rate formulas (Ch. 9, 29)
- `translation-brief.md` and `glossary.xlsx`: consistent translations (Ch. 12)
- `research-brief.md`: six-edge research brief (Ch. 13)

## prompts/
- `ch05` to `ch09`: each chapter's copy-ready prompts, without the teaching pins
- `ch14-market-report.md`: the full research-to-decision chain
- `ch15-documents.md`: PDFs, photos, version comparison, charts
- `ch20-pricing-tool.md`: build and fix prompts, formulas, and the six test cases
- `library-120.md`: plain-text copy of all 120 prompts, for clean copy and paste (the designed version is *The 120-Prompt Playbook*)

## data/ (fictional practice data, fixed seed)
- `nada-sales-aug-oct-raw.csv`: 1,206 raw order lines with deliberate issues (Ch. 16)
- `nada-sales-aug-oct-clean.csv`: the cleaned 1,194 lines, for checking your result
- `product-costs.csv`: unit costs for margin analysis (Ch. 16)
- `supplier-prices-oct.pdf`, `delivery-note-photo.jpg`: extraction practice (Ch. 15)

## code/
- `merge_exports.py`: the Chapter 24 script. Dry run by default; writes only with `--go`.

Names and figures in the running example (Rana, Nada Roastery) are fictional, created for teaching.
ARROWS, the scoring card, the detail scale, and the verification protocol are teaching tools by the author, not official Anthropic methods.
Not affiliated with or endorsed by Anthropic.

_Last reviewed: 2026-10-19_
