# Template: short product descriptions · v1.1 · 2026-10

- **When:** adding new products to a shop.
- **Tested on:** (log the model, effort level, and number of inputs)
- **Fails when:** (log what you discover)

```
Write product descriptions for [shop name]. The reader is [who, and where they read].
Follow the examples' structure and voice, not their wording: [structure and length].
<examples>
<example>
[example 1]
</example>
<example>
[example 2 — different content]
</example>
<example>
[example 3 — a different case, such as a blend or seasonal product]
</example>
</examples>
Write one description for each product below, using only the notes given for it.
If a product's notes are empty, write "[fallback line]" and don't suggest anything of your own.
<products>
[name | notes | roast | brewing]
</products>
```

_Last reviewed: 2026-10-17_
