# Research brief (Chapter 13)

_Claude Without Guesswork · October 2026 Edition · companion pack. Copy, then replace every [bracketed slot]._

Fill all six edges before you start: topic, place, time, source rules, exclusions, output.

## Improved prompt · research brief

```text
Research question: what are the main channels through which specialty-coffee roasters sell to businesses (offices, hotels, cafés) in Jordan and neighboring markets, and how do they price those deals?
Place: Jordan first; Gulf and Levant markets only as comparisons, labeled as such.
Time: sources from 2023 onward; flag anything older.
Source rules: prefer official statistics, trade bodies, and named companies' own pages. Treat vendor blogs and "market size" press releases as weak, and say so.
Exclude: home-consumer retail.
Output: a short summary (5 bullets), then a table of findings: claim, source, date, source type, and your confidence. End with what you couldn't find.
```

## Research · web plus internal

```text
Use the research tool. Question: which of our wholesale clients are most at risk of leaving in the next quarter, and what are competitors offering them?
Internal: look through my Gmail threads labeled "wholesale" from the last six months for complaints, price questions, and late payments.
External: search for current wholesale coffee offers from roasters in Amman.
Keep internal findings and web findings in separate sections, each with its sources. Don't name clients in any web search.
```

