# Translation brief (Chapter 12)

_Claude Without Guesswork · October 2026 Edition · companion pack. Copy, then replace every [bracketed slot]._

## Translation brief

```text
Translate the product page below from English into Arabic.
Audience: customers in Jordan shopping on their phones. Register: Modern Standard Arabic, warm and simple, no formal flourishes.
Keep in Latin script exactly as written: brand names, coffee origins (Huila, Yirgacheffe), and order codes.
Prices: keep "JOD" and Western digits (9.00 JOD).
Use the glossary in <glossary>; never substitute a synonym for a glossary term.
Preserve headings, bullets, and line breaks.
After the translation, list anything you weren't sure how to render, with the options you considered.
<glossary>[term = approved translation, one per line]</glossary>
<page>[paste]</page>
```

## Checklist after translating

- Every glossary term used exactly as approved
- Names, origins, and order codes unchanged
- Prices, digits, and units unchanged
- Headings and bullets preserved
- The "not sure" list reviewed by a fluent reader before publishing
