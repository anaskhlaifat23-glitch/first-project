# Template: handoff summary between chats (Chapter 7)

```
I'll continue this work in a new chat. Write a handoff summary of up to 200 words covering:
1. The end goal of the work.
2. The decisions I've made, with my reasons if I gave them.
3. The key figures and facts we're relying on.
4. What's done, and what's left, in order.
5. Any constraints or preferences I've asked for.
Write it so someone who never saw this chat could pick up the work.
```

Read the summary and correct it before carrying it into the new chat.

_Last reviewed: 2026-10-17_
