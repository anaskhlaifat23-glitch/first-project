# The ARROWS template (*Claude Without Guesswork*, Chapter 5)

> A teaching framework by the author, not an official Anthropic method.
> Delete any section that doesn't change the result. Replace everything in square brackets.
> Suggested thinking order: Reality → Aim → Request, then the three guardrails.

```
[REALITY]
I'm [your role / who you are], and [what needs to be known about the situation]. This output is for [the reader or user].

[AIM]
I want [the result that should happen once the output is used].

[REQUEST]
[The exact action: write / summarize / analyze / compare…] based on:
- [fact or input 1]
- [fact or input 2]

[OUTPUT]
Write in [language and variety, e.g. US English], at [length], as [an email / a table / paragraphs…].

[WALLS]
[What to avoid, phrased positively where possible]. If you need information that isn't here, write "Not available." Don't guess.

[STANDARD]
I'll consider the output ready if [a checkable condition].
```

## Scoring card (12 points)

| Element | 0 | 1 | 2 |
|---|---|---|---|
| Aim | Missing | Implied | Explicit |
| Reality | Missing | Partial | Enough |
| Request | Vague | General | Precise |
| Output | No | Partly | Yes |
| Walls | No | Partly | Yes |
| Standard | No | Fuzzy | Checkable |

9–12 ready for important work · 6–8 fine for a draft · 0–5 rewrite, or keep it short on purpose.

## The detail scale (four questions)

1. Is a mistake costly? 2. Will someone else use it? 3. Does the format matter? 4. Is Claude missing the background?
Zero "yes": one direct line · one or two: ARROWS core · three or more: full spec.

_Last reviewed: 2026-10-17_
