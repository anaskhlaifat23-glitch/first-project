# Prompt card (Chapter 10)

| Field | Value |
|---|---|
| Name | |
| Version and date | v1.0 · YYYY-MM |
| Purpose | |
| Slots | |
| Tested on | Model · effort level · number of inputs |
| Test set | X of 10 (round N) |
| Fails when | |
| Category | Writing / Analysis / Research / Data |

## Template text

```
[paste the template here]
```

## Change log

- v1.0 — YYYY-MM — first version

_Last reviewed: 2026-10-17_
