import csv, sys
from pathlib import Path

folder = Path("exports")              # where the monthly CSV files are
output = Path("merged.csv")           # the file this script creates
dry_run = "--go" not in sys.argv      # nothing is written unless you add --go

files = sorted(folder.glob("*.csv"))
rows, header = [], None
for f in files:
    with f.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        header = header or reader.fieldnames
        for row in reader:
            row["source_file"] = f.name
            rows.append(row)

print(f"{len(files)} files, {len(rows)} rows found.")
if dry_run:
    print("Dry run: nothing written. Run again with --go to create", output)
else:
    with output.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=header + ["source_file"])
        writer.writeheader()
        writer.writerows(rows)
    print("Wrote", output)
